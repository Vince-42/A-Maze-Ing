# ######### comments ##########

# Configuration file of the A-Maze-Ing project

# ######### import  ##########

from utils import error as err
import random

# ######### class   ##########


class Configuration():
    def __init__(self):
        self.__file_name: str = "config.txt"
        self._width: int = -1
        self._height: int = -1
        self._entry: tuple = ()
        self._exit: tuple = ()
        self._output_file: str = ""
        self._perfect = None
        self._seed: int = None
        self._algorythm = "Backtracking"
        self._display_mode = "ASCII"
        self._data_check: int = 0

    def extract(self):
        with open(self.__file_name, "r") as f:
            for line in f:
                if line[0] != '#' and line[0] != "\n":
                    self.parsing_file(line)

    def parsing_file(self, line: str):
        indicator = ["WIDTH=", "HEIGHT=", "ENTRY=", "EXIT=", "OUTPUT_FILE=",
                     "PERFECT=", "SEED="]
        for truc in indicator:
            if truc in line:
                self.placing_data(truc, line.rstrip())

    def placing_data(self, truc, line):
        if truc == "WIDTH=":
            x = self.split_int(line)
            self._width = x
        elif truc == "HEIGHT=":
            y = self.split_int(line)
            self._height = y
        elif truc == "ENTRY=":
            z = self.split_tuple(line)
            self._entry = z
        elif truc == "EXIT=":
            a = self.split_tuple(line)
            self._exit = a
        elif truc == "OUTPUT_FILE=":
            b = self.split_str(line)
            if b == "":
                raise err.StringError("String cannot be empty")
            self._output_file = b
        elif truc == "PERFECT=":
            c = self.split_bool(line)
            self._perfect = c
        elif truc == "SEED=":
            d = self.split_seed(line)
            self._seed = d
            random.seed(self._seed)

    # return 'True' or 'False' on success | 'None' on failed
    def split_bool(self, line) -> bool:
        accept = {"True", "True\n"}
        false = {"False", "False\n"}
        rslt = line.split("=")
        try:
            if rslt[1] in accept:
                self._data_check += 1
                return True
            elif rslt[1] in false:
                self._data_check += 1
                return False
            else:
                raise err.BooleanError("Perfect must be True or False")
        except err.BooleanError:
            raise err.BooleanError

    # return a positive INT on success | neg on failed
    def split_int(self, line) -> int:
        rslt = line.split("=")
        # verifier que line [1] est bien un integer
        # return l'intenger si positive
        try:
            ret = int(rslt[1])
            if ret < 0:
                raise err.NegativeError("Integer cannot be negative.")
            self._data_check += 1
            return ret
        except TypeError as e:
            print(f"WRONG DATA : {e}")
        return -1

        # return a positive INT on success | neg on failed
    def split_seed(self, line) -> int | None:
        rslt = line.split("=")
        # verifier que line [1] est bien un integer
        # return l'intenger si positive
        try:
            if rslt[1] == "None":
                return None
            ret = int(rslt[1])
            if ret < 0:
                raise err.NegativeError("Seed cannot be negative.")
            return ret
        except TypeError as e:
            print(f"WRONG SEED DATA : {e}")
        return None

    # return an STR on success | empty on fail
    def split_str(self, line) -> str:
        rslt = line.split("=")
        try:
            ret = str(rslt[1])
            self._data_check += 1
            return ret
        except TypeError as e:
            print(f"WRONG DATA : {e}")
        return ""

        # return a TUPLE on success | (-1, -1) on fail
    def split_tuple(self, line) -> tuple:
        rslt = line.split("=")
        try:
            dt = rslt[1]
            dt_split = dt.split(",")
            if len(dt_split) != 2:
                raise err.TupleError("Coordinate can not be more than 2D.")
            dt_split[0] = int(dt_split[0])
            dt_split[1] = int(dt_split[1])
            if dt_split[0] < 0 or dt_split[1] < 0:
                raise err.NegativeError("Integer cannot be negative.")
            self._data_check += 1
            return tuple(dt_split)
        except TypeError as e:
            print(f"WRONG DATA : {e}")
        return (-1, -1)

    def validation(self):
        # checking entry/exit
        # NEED TO BE SURE THAT ENTRANCE AND EXIT ARE ON THE BORDER
        if int(self._exit[0]) > self._width or\
           int(self._exit[1]) > self._height:
            self._data_check -= 1
            raise err.EntryExitError("Entry point outside of the maze.")
        if self._entry == self._exit:
            self._data_check -= 1
            raise err.EntryExitError("Entry can't be the same as the Exit.")
        if int(self._entry[0]) > self._width or\
           int(self._entry[1]) > self._height:
            self._data_check -= 1
            raise err.EntryExitError("Exit can't be outside maze limits.")
        if int(self._exit[0]) >= self._width or\
           int(self._exit[1]) >= self._height:
            self._data_check -= 1
            raise err.EntryExitError("Exit can't be outside the maze limits.")

# ######### methods ##########


def main_config():
    default = Configuration()
    try:
        default.extract()
        default.validation()
    except ValueError as error:
        print(f"Error in config file : {error}")
    except err.TupleError as e:
        print(f"Error in Tuple validation. {e}")
    except err.NegativeError as e:
        print(f"The config value cannot be negative. {e}")
    except FileNotFoundError as e:
        print(f"Error in the file name or location. {e}")
    except err.BooleanError as e:
        print(f"Error in the boolean part of config file. {e}")
    except err.EntryExitError as e:
        print(f"Error in the entry/exit parameters. {e}")
    except err.StringError as e:
        print(f"Empty string. {e}")
    return default
