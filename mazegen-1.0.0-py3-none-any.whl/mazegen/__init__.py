"""Public interface for the reusable maze generator."""

from core.maze_generator import MazeGenerator

__all__ = ["MazeGenerator"]